import java.rmi.Naming;
import java.util.Scanner;

public class HotelClient {
    public static void main(String[] args) {
        try {
            HotelInterface hotel = (HotelInterface) Naming.lookup("//localhost/HotelService");
            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("1. Book room");
                System.out.println("2. Cancel Booking");
                System.out.println("3. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.print("Enter guest name: ");
                        String guestName = scanner.nextLine();
                        boolean booked = hotel.bookRoom(guestName);
                        if (booked) {
                            System.out.println("Room booked successfully!");
                        } else {
                            System.out.println("Failed to book room. Room already booked for this guest.");
                        }
                        break;
                    case 2:
                        System.out.print("Enter guest name to cancel booking: ");
                        String cancelName = scanner.nextLine();
                        boolean canceled = hotel.cancelBooking(cancelName);
                        if (canceled) {
                            System.out.println("Booking canceled successfully!");
                        } else {
                            System.out.println("No booking found for this guest.");
                        }
                        break;
                    case 3:
                        System.out.println("Exiting...");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please enter a valid option.");
                }
            }
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
