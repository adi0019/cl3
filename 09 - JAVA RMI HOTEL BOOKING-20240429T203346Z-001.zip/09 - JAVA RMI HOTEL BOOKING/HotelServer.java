import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;

public class HotelServer extends UnicastRemoteObject implements HotelInterface {
    private Map<String, String> bookings; // Mapping of guestName to room number

    public HotelServer() throws RemoteException {
        super();
        bookings = new HashMap<>();
    }

    @Override
    public synchronized boolean bookRoom(String guestName) throws RemoteException {
        if (!bookings.containsKey(guestName)) {
            // Simulate booking logic (in real system, this would involve database operations)
            bookings.put(guestName, "Room101"); // For simplicity, just assign Room101
            return true;
        }
        return false; // Room already booked for this guest
    }

    @Override
    public synchronized boolean cancelBooking(String guestName) throws RemoteException {
        if (bookings.containsKey(guestName)) {
            bookings.remove(guestName);
            return true;
        }
        return false; // No booking found for this guest
    }

    public static void main(String[] args) {
        try {
            HotelServer server = new HotelServer();
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            java.rmi.registry.Registry registry = java.rmi.registry.LocateRegistry.getRegistry();
            registry.rebind("HotelService", server);
            System.out.println("Server started...");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
