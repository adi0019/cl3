import java.rmi.Remote;
import java.rmi.RemoteException;

public interface HotelInterface extends Remote {
    boolean bookRoom(String guestName) throws RemoteException;
    boolean cancelBooking(String guestName) throws RemoteException;
}
