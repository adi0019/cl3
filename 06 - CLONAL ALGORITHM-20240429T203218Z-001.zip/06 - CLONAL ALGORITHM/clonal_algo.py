import random
import math

# Define the objective function (in this case, a simple quadratic function)
def objective_function(x):
    return x**2

# Define the antibody class
class Antibody:
    def __init__(self, length, min_val, max_val):
        self.length = length
        self.min_val = min_val
        self.max_val = max_val
        self.vector = [random.uniform(min_val, max_val) for _ in range(length)]
        self.fitness = objective_function(sum(self.vector))

    # Function to clone the antibody
    def clone(self):
        clone = Antibody(self.length, self.min_val, self.max_val)
        clone.vector = self.vector.copy()
        return clone

    # Function to mutate the antibody
    def mutate(self, mutation_rate):
        for i in range(self.length):
            if random.uniform(0, 1) < mutation_rate:
                self.vector[i] = random.uniform(self.min_val, self.max_val)
        self.fitness = objective_function(sum(self.vector))

# Clonal Selection Algorithm
def clonal_selection(population_size, num_generations, mutation_rate, clone_rate):
    # Initialize the population
    population = [Antibody(1, -10, 10) for _ in range(population_size)]

    for generation in range(num_generations):
        # Sort the population based on fitness
        population.sort(key=lambda x: x.fitness)

        # Select the best antibodies for cloning
        clones = []
        for antibody in population[:int(population_size * clone_rate)]:
            num_clones = int(antibody.fitness * 10)  # Adjust the scaling factor as needed
            for _ in range(num_clones):
                clone = antibody.clone()
                clone.mutate(mutation_rate)
                clones.append(clone)

        # Merge the clones with the existing population
        population.extend(clones)

        # Sort the population based on fitness and keep the best individuals
        population.sort(key=lambda x: x.fitness)
        population = population[:population_size]

    # Return the best solution found
    best_solution = min(population, key=lambda x: x.fitness)
    return best_solution.vector, best_solution.fitness

# Example usage
population_size = 100
num_generations = 100
mutation_rate = 0.1
clone_rate = 0.2

solution, fitness = clonal_selection(population_size, num_generations, mutation_rate, clone_rate)
print(f"Best solution found: {solution}")
print(f"Fitness value: {fitness}")